import * as React from "react";
import Container from "@mui/material/Container";
import Sidebar from "./component/sidebar";
import '@fontsource/public-sans';

function App() {
  return (
      <Sidebar/>
  );
}

export default App;
